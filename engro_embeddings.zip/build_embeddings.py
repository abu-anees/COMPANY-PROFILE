"""
Build an embeddings file from a single PDF for a Streamlit RAG app.
Free + local. Two modes:
  python build_embeddings.py report.pdf            -> neural embeddings (sentence-transformers, best quality)
  python build_embeddings.py report.pdf --tfidf    -> TF-IDF embeddings (no model download, works offline)
Outputs (in ./embeddings/): chunks.json, embeddings.npy (or tfidf.npz), meta.json (+ tfidf_vectorizer.pkl)
"""
import sys, re, json, os, pickle
import numpy as np
from pypdf import PdfReader

CHUNK_WORDS, OVERLAP = 220, 40
OUT = "embeddings"

def extract_pages(path):
    reader = PdfReader(path)
    for i, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{2,}", "\n", text).strip()
        if len(text) > 50:
            yield i, text

def make_chunks(pages):
    chunks = []
    for page_no, text in pages:
        words = text.split()
        step = CHUNK_WORDS - OVERLAP
        for start in range(0, max(len(words), 1), step):
            piece = " ".join(words[start:start + CHUNK_WORDS])
            if len(piece.split()) >= 30:
                chunks.append({"id": len(chunks), "page": page_no, "text": piece})
            if start + CHUNK_WORDS >= len(words):
                break
    return chunks

def main():
    pdf = sys.argv[1]
    use_tfidf = "--tfidf" in sys.argv
    os.makedirs(OUT, exist_ok=True)
    chunks = make_chunks(extract_pages(pdf))
    texts = [c["text"] for c in chunks]
    print(f"{len(chunks)} chunks")

    if use_tfidf:
        from sklearn.feature_extraction.text import TfidfVectorizer
        import scipy.sparse as sp
        vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2),
                              min_df=2, max_features=60000, sublinear_tf=True)
        mat = vec.fit_transform(texts)
        sp.save_npz(f"{OUT}/tfidf.npz", mat)
        pickle.dump(vec, open(f"{OUT}/tfidf_vectorizer.pkl", "wb"))
        meta = {"type": "tfidf", "pdf": os.path.basename(pdf), "chunks": len(chunks)}
    else:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("all-MiniLM-L6-v2")
        emb = model.encode(texts, batch_size=64, show_progress_bar=True,
                           normalize_embeddings=True)
        np.save(f"{OUT}/embeddings.npy", emb.astype("float32"))
        meta = {"type": "neural", "model": "all-MiniLM-L6-v2",
                "pdf": os.path.basename(pdf), "chunks": len(chunks)}

    json.dump(chunks, open(f"{OUT}/chunks.json", "w", encoding="utf-8"))
    json.dump(meta, open(f"{OUT}/meta.json", "w"))
    print("saved to", OUT)

if __name__ == "__main__":
    main()
