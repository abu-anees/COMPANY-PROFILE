import json, pickle
import numpy as np
import scipy.sparse as sp
from sklearn.metrics.pairwise import cosine_similarity

def load_index(folder="embeddings"):
    chunks = json.load(open(f"{folder}/chunks.json", encoding="utf-8"))
    meta = json.load(open(f"{folder}/meta.json"))
    if meta["type"] == "tfidf":
        mat = sp.load_npz(f"{folder}/tfidf.npz")
        vec = pickle.load(open(f"{folder}/tfidf_vectorizer.pkl", "rb"))
        return chunks, meta, (mat, vec)
    emb = np.load(f"{folder}/embeddings.npy")
    return chunks, meta, emb

def search(query, chunks, meta, index, k=5):
    if meta["type"] == "tfidf":
        mat, vec = index
        scores = cosine_similarity(vec.transform([query]), mat).ravel()
    else:
        from sentence_transformers import SentenceTransformer
        q = SentenceTransformer(meta["model"]).encode([query], normalize_embeddings=True)
        scores = (index @ q.T).ravel()
    top = np.argsort(-scores)[:k]
    return [(chunks[i], float(scores[i])) for i in top]

if __name__ == "__main__":
    chunks, meta, index = load_index()
    for q in ["What was the net profit in 2024?", "Who is the chairman of the board?"]:
        print("\nQ:", q)
        for c, s in search(q, chunks, meta, index, 3):
            print(f"  p.{c['page']} ({s:.2f}): {c['text'][:150]}...")
